import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  Button,
} from 'react-native';

export default function App() {
  const [page, setPage] = useState(1);

  if (page === 1) {
    return (
      <ScrollView style={styles.screen}>
        <Text style={styles.header}>Журнал Bright</Text>

        <View style={styles.card}>
          <Text style={styles.category}>Новости</Text>

          <Image
            style={styles.image}
            source={{
              uri: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d',
            }}
          />

          <Text style={styles.title}>
            Превращаем стресс в своего помощника
          </Text>

          <Text style={styles.text}>
            Исследователи Йельского университета заявляют, что люди, которые
            рассматривают стресс, как возможность личностного роста, отмечают
            улучшение качества жизни. Сегодня узнаем, как это работает и как
            увидеть положительные стороны стресса.
          </Text>

          <View style={styles.button}>
            <Button
              title="Читать далее"
              onPress={() => setPage(2)}
            />
          </View>
        </View>
      </ScrollView>
    );
  }

  // ===== 2-БЕТ (толық оқу) =====
  return (
    <View style={styles.screen}>
      <Text style={styles.header}>Толық мақала</Text>

      <Text style={styles.text}>
        Бұл жерде мақаланың толық нұсқасы орналасады.
        Стресс – бұл тек қиындық емес, ол даму құралы болуы мүмкін.
        Оны дұрыс қабылдау арқылы адам өз өмір сапасын жақсарта алады.
      </Text>

      <View style={styles.button}>
        <Button
          title="Артқа қайту"
          onPress={() => setPage(1)}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: '#f2f2f2',
    padding: 15,
    flex: 1,
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
  },
  category: {
    color: 'blue',
    marginBottom: 10,
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  text: {
    fontSize: 16,
    lineHeight: 22,
    marginBottom: 15,
  },
  button: {
    marginTop: 10,
  },
});
